-- Creazione Database
CREATE DATABASE ToysGroupDB;
use ToysGroupDB;

-- Tabella Prodotti

CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(50),
    Category VARCHAR(50)
);

-- Tabella Regioni

CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(50)
);

-- Tabella Vendite 

CREATE TABLE Sales (
    SalesID INT PRIMARY KEY,
    ProductID INT,
    RegionID INT,
    SalesDate DATE,
    Quantity INT,
    Price DECIMAL(10 , 2 ),
    FOREIGN KEY (ProductID)
        REFERENCES Product (ProductID),
    FOREIGN KEY (RegionID)
        REFERENCES Region (RegionID)
);
        
-- Inseriamo i dati nella tabella prodotti

INSERT INTO Product (ProductID, ProductName, Category) VALUES
(1, 'Barbie Midge 60 Anniversario', 'Dolls'),
(2, 'Funko Pop! Marvel: Spider-man Across The Spider-Verse', 'Funko'),
(3, 'Scarlatto & Violetto: Evoluzioni a Paldea - Display 36 Buste', 'Pokemon'),
(4, 'Hot Wheels Boulevard Macchinine', 'Car'),
(5, 'Hot Wheels Monster Trucks', 'Car'),
(6, 'Barbie Cieca Con Outfit Color Pastello', 'Dolls'),
(7, 'Scarlatto & Violetto: Crepuscolo Mascherato - Set Allenatore Fuoriclasse', 'Pokemon'),
(8, 'Funko Pop Keychain - Shrek', 'Funko'),
(9, 'Funko Pop Basketball 84 - Michael Jordan', 'Funko'),
(10, 'Funko Pop Games 950 - Umbreon', 'Funko');

-- Inseriamo i dati nella tabella Regioni

INSERT INTO Region (RegionID, RegionName) VALUES
(1, 'Italia'),
(2, 'USA'),
(3, 'Giappone'),
(4, 'Ecuador'),
(5, 'Turchia'),
(6, 'Spagna');

-- inseriamo i dati nella tabella vendite (generato tramite chat gpt)

INSERT INTO Sales (SalesID, ProductID, RegionID, SalesDate, Quantity, Price) VALUES
(1, 3, 2, '2023-01-10', 120, 19.00),
(2, 5, 1, '2023-01-15', 160, 14.00),
(3, 7, 4, '2023-02-10', 210, 159.00),
(4, 1, 5, '2023-02-20', 55, 19.00),
(5, 9, 3, '2023-03-10', 80, 159.00),
(6, 4, 2, '2023-03-20', 130, 9.00),
(7, 8, 1, '2023-04-10', 65, 13.00),
(8, 6, 4, '2023-04-20', 85, 15.00),
(9, 2, 5, '2023-05-10', 95, 65.00),
(10, 7, 3, '2023-05-20', 115, 10.00),
(11, 1, 1, '2023-06-10', 135, 25.00),
(12, 6, 5, '2023-06-20', 145, 25.00),
(13, 5, 2, '2023-07-10', 155, 14.00),
(14, 8, 3, '2023-07-20', 165, 159.00),
(15, 4, 4, '2023-08-10', 175, 9.00),
(16, 3, 1, '2023-08-20', 185, 13.00),
(17, 7, 2, '2023-09-10', 195, 15.00),
(18, 9, 5, '2023-09-20', 205, 65.00),
(19, 2, 4, '2023-10-10', 215, 10.00),
(20, 5, 1, '2023-10-20', 175, 9.00),
(21, 8, 3, '2023-11-10', 185, 13.00),
(22, 1, 2, '2023-11-20', 195, 15.00),
(23, 3, 4, '2023-12-10', 205, 65.00),
(24, 4, 5, '2023-12-20', 215, 10.00),
(25, 7, 3, '2023-06-05', 225, 25.00),
(26, 8, 2, '2023-06-10', 110, 15.00),
(27, 9, 1, '2023-07-10', 120, 65.00),
(28, 1, 4, '2023-08-10', 130, 10.00),
(29, 2, 5, '2023-09-10', 140, 25.00),
(30, 5, 2, '2023-10-10', 150, 19.00),
(31, 3, 4, '2023-11-10', 160, 14.00),
(32, 4, 1, '2023-12-10', 170, 159.00),
(33, 7, 5, '2023-01-10', 55, 19.00),
(34, 8, 3, '2023-02-10', 65, 14.00),
(35, 9, 4, '2023-03-10', 75, 159.00),
(36, 2, 2, '2023-04-10', 85, 9.00),
(37, 5, 3, '2023-05-10', 95, 13.00),
(38, 6, 4, '2023-01-20', 125, 15.00),
(39, 7, 5, '2023-02-25', 135, 65.00),
(40, 8, 1, '2023-03-30', 145, 10.00);

SELECT 
    ProductID, COUNT(*)
FROM
    Product
GROUP BY ProductID
HAVING COUNT(*) > 1;

-- 1. Verificare che i campi definiti come PK siano univoci

-- Verifichiamo l'unicità di RegionID

SELECT RegionID, COUNT(*)
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1;

-- Verifichiamo l'unicità di SalesID

SELECT SalesID, COUNT(*)
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) > 1;

-- 2 Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.
  
Create view Fatturato_dei_Prodotti_per_anno as (SELECT
    P.ProductName,
    YEAR(S.SalesDate) AS Year,
    SUM(S.Quantity * S.Price) AS TotalRevenue
FROM
    Sales S
    JOIN Product P ON S.ProductID = P.ProductID
GROUP BY
    P.ProductName,
    YEAR(S.SalesDate));

-- 3. Esporre il fatturato totale per regione per anno, ordinando il risultato per data e per fatturato decrescente

Create view Fatturato_per_regione AS (SELECT
    R.RegionName,
    YEAR(S.SalesDate) AS Year,
    SUM(S.Quantity * S.Price) AS TotalRevenue
FROM
    Sales S
    JOIN Region R ON S.RegionID = R.RegionID
GROUP BY
    R.RegionName,
    YEAR(S.SalesDate)
ORDER BY
    YEAR(S.SalesDate),
    TotalRevenue DESC);

 -- 4. Qual è la categoria di articoli maggiormente richiesta dal mercato?
 
CREATE VIEW Categoria_più_richiesta AS
SELECT 
    P.Category, 
    SUM(S.Quantity) AS Total_quantity_sales
FROM
    Sales S
    JOIN Product P ON S.ProductID = P.ProductID
GROUP BY P.Category
ORDER BY Total_quantity_sales DESC
LIMIT 1;

-- la domanda 5 l'ho saltata perche non sapevo come fare

-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita

CREATE VIEW Data_ultima_vendita AS
    (SELECT 
        P.ProductName, MAX(S.SalesDate) AS LastSaleDate
    FROM
        Sales S
            JOIN
        Product P ON S.ProductID = P.ProductID
    GROUP BY P.ProductName);